import { Aleo } from 'next/font/google';

// Define the Aleo font with the variants we need
export const aleo = Aleo({
  subsets: ['latin'],
  weight: ['400', '700'],
  display: 'swap',
  variable: '--font-aleo',
});
